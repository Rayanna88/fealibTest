#!/usr/bin/env python3
"""
validate_expression_yaml.py
===========================
校验 fealib-cpp Expression YAML 配置文件是否合法。

对应 C++ 解析逻辑：
  src/expression_parser.cc  — Parser::parse / parse_inputs / parse_output
  src/expression_executor.cc — select_executor / build_config
  src/expression.cc          — Expression::build

用法
----
  # 校验单个文件
  python3 scripts/validate_expression_yaml.py config/features.yaml

  # 校验多个文件
  python3 scripts/validate_expression_yaml.py feat1.yaml feat2.yaml

  # 从 stdin 读取（管道）
  cat features.yaml | python3 scripts/validate_expression_yaml.py -

  # 详细输出（打印每条表达式的解析摘要）
  python3 scripts/validate_expression_yaml.py -v features.yaml
"""

import sys
import argparse
import traceback
from typing import Any, Dict, List, Optional, Tuple

try:
    import yaml
except ImportError:
    print("ERROR: 缺少依赖 pyyaml，请先安装：pip install pyyaml", file=sys.stderr)
    sys.exit(1)

# ============================================================================
# 常量（与 C++ constants.h 保持一致）
# ============================================================================

VALID_VAR_TAGS = {
    "!var_int32",
    "!var_int64",
    "!var_float",
    "!var_string",
    "!var_int32_array",
    "!var_int64_array",
    "!var_float_array",
    "!var_string_array",
}

VALID_CONST_TAGS = {
    "!const_int32",
    "!const_int64",
    "!const_float",
    "!const_string",
    "!const_int32_array",
    "!const_int64_array",
    "!const_float_array",
    "!const_string_array",
}

ARRAY_CONST_TAGS = {
    "!const_int32_array",
    "!const_int64_array",
    "!const_float_array",
    "!const_string_array",
}

ARRAY_VAR_TAGS = {
    "!var_int32_array",
    "!var_int64_array",
    "!var_float_array",
    "!var_string_array",
}

VALID_FIELD_PREFIXES = ("user.", "item.", "ctx.")

DEFAULT_HASH_MASK = 0x1FFFFFFFFFFFFF  # 2^53 - 1

# op -> 输出类型映射（描述用，校验用）
# "float"  : float / float_array
# "int32"  : int32 / int32_array
# "int64"  : int64 / int64_array
# "string" : string / string_array
# "any"    : 取决于输入，无法静态确定
OP_OUTPUT_TYPE: Dict[str, str] = {
    # 透传
    "identity":              "any",
    # 算术（返回与输入相同类型，但 float/int 运算大多返回 float 或同类）
    "add": "any", "sub": "any", "mul": "any", "div": "any", "mod": "any",
    # 数学
    "abs":     "any",
    "ceil":    "int32",
    "floor":   "int32",
    "round":   "int32",
    "exp":     "float",
    "log":     "float",
    "log10":   "float",
    "log2":    "float",
    "sqrt":    "float",
    "sigmoid": "float",
    "pow":     "float",
    "scale":   "int32",
    "wilson_score": "float",
    "smooth":  "float",
    "z_score": "float",
    # 统计
    "min": "any", "max": "any",
    "avg": "float", "var": "float", "std": "float",
    "norm":       "float",
    "normalize":  "float_array",
    "dot_product":"float",
    "count":      "int32",
    "topk":       "any",
    # 离散化
    "binarize":           "int32",
    "bucketize":          "int32",
    "min_max_normalize":  "float",
    # 向量工具
    "len":      "int32",
    "contains": "string",
    # 字符串
    "lower":        "string",
    "upper":        "string",
    "reverse":      "string",
    "substr":       "string",
    "match_prefix": "string",
    # 拼接
    "concat":            "string",
    "concat_ws":         "string",
    "lower_concat_ws":   "string",
    "trim_concat":       "string",
    "trim_concat_ws":    "string",
    "cartesian_concat":  "string_array",
    # 日期
    "year": "string", "month": "string", "day": "string",
    "weekday": "string", "curdate": "string",
    "unix_timestamp": "int64",
    "from_unixtime":  "string",
    "date_add":       "string",
    "date_sub":       "string",
    "datediff":       "int64",
    # 距离
    "edit_distance":          "float",
    "cosine_distance":        "float",
    "jaccard_distance":       "float",
    "jaro_winkler_distance":  "float",
    "fuzzy":                  "float",
}

# ============================================================================
# YAML 自定义加载器（保留 tag 信息）
# ============================================================================

class TaggedValue:
    """包装带 YAML tag 的标量/序列"""
    def __init__(self, tag: str, value: Any):
        self.tag = tag
        self.value = value

    def __repr__(self) -> str:
        return f"TaggedValue({self.tag!r}, {self.value!r})"


def _make_tagged_loader() -> type:
    """构造一个保留所有自定义 tag 的 YAML Loader"""
    loader_cls = yaml.SafeLoader

    class TaggedLoader(loader_cls):
        pass

    # 捕获所有未知 tag（!var_* / !const_*）
    def _construct_tagged_scalar(loader, tag_suffix, node):
        value = loader.construct_scalar(node)
        return TaggedValue("!" + tag_suffix, value)

    def _construct_tagged_sequence(loader, tag_suffix, node):
        value = loader.construct_sequence(node, deep=True)
        return TaggedValue("!" + tag_suffix, value)

    # 注册 !var_* 和 !const_* 两种 tag 前缀
    for prefix in ("var", "const"):
        TaggedLoader.add_multi_constructor(
            f"!{prefix}_",
            lambda loader, tag_suffix, node, p=prefix: (
                _construct_tagged_sequence(loader, tag_suffix, node)
                if isinstance(node, yaml.SequenceNode)
                else _construct_tagged_scalar(loader, tag_suffix, node)
            ),
        )

    return TaggedLoader


_TAGGED_LOADER = _make_tagged_loader()


def load_yaml(text: str) -> Any:
    return yaml.load(text, Loader=_TAGGED_LOADER)


# ============================================================================
# 错误收集器
# ============================================================================

class ValidationError(Exception):
    pass


class ErrorCollector:
    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def error(self, msg: str):
        self.errors.append(msg)

    def warn(self, msg: str):
        self.warnings.append(msg)

    def ok(self) -> bool:
        return len(self.errors) == 0


# ============================================================================
# 单条表达式校验
# ============================================================================

def validate_expression(node: Dict, ec: ErrorCollector, verbose: bool = False) -> Optional[Dict]:
    """
    校验单条表达式 YAML 节点。
    返回解析摘要（用于 verbose 输出），发现错误时写入 ec。
    """
    # ---------- 1. name ----------
    if "name" not in node:
        ec.error("缺少必填字段 'name'")
        return None
    name = node["name"]
    if not isinstance(name, str) or not name.strip():
        ec.error(f"[name={name!r}] 'name' 不可为空字符串")
        return None

    ctx = f"[{name}]"

    # ---------- 2. op ----------
    if "op" not in node:
        ec.error(f"{ctx} 缺少必填字段 'op'")
        return None
    op = node["op"]
    if not isinstance(op, str) or not op.strip():
        ec.error(f"{ctx} 'op' 不可为空字符串")

    op_output_type = OP_OUTPUT_TYPE.get(op)
    if op_output_type is None:
        ec.warn(f"{ctx} 'op={op}' 不在已知内置函数列表中（可能是自定义扩展，跳过类型约束校验）")
        op_output_type = "any"

    # ---------- 3. input ----------
    if "input" not in node:
        ec.error(f"{ctx} 缺少必填字段 'input'")
        return None

    inputs = node["input"]
    if not isinstance(inputs, list) or len(inputs) == 0:
        ec.error(f"{ctx} 'input' 必须是非空列表")
        return None

    parsed_inputs = []
    for i, item in enumerate(inputs):
        result = _validate_input_item(ctx, i, item, ec)
        if result:
            parsed_inputs.append(result)

    # ---------- 4. hash（可选）----------
    has_hash = False
    hash_mask = DEFAULT_HASH_MASK
    hash_prefix = ""
    if "hash" in node:
        has_hash = True
        hash_node = node["hash"]
        if hash_node is not None:
            if "mask" in hash_node:
                mask_val = hash_node["mask"]
                if not isinstance(mask_val, int) or mask_val <= 0:
                    ec.error(f"{ctx} 'hash.mask' 必须为正整数，当前值：{mask_val!r}")
                else:
                    hash_mask = mask_val
            if "prefix" in hash_node:
                hash_prefix = hash_node["prefix"]
                if not isinstance(hash_prefix, str):
                    ec.error(f"{ctx} 'hash.prefix' 必须为字符串")

    # ---------- 5. export ----------
    if "export" not in node:
        ec.error(f"{ctx} 缺少必填字段 'export'")
        return None

    export_node = node["export"]
    if not isinstance(export_node, dict):
        ec.error(f"{ctx} 'export' 必须是映射（mapping）")
        return None

    slot, has_padding, pad_len, pad_val = _validate_export(ctx, export_node, ec)

    # ---------- 6. 类型约束校验 ----------
    _validate_type_constraints(
        ctx, op, op_output_type, has_hash, hash_prefix, has_padding, ec
    )

    summary = {
        "name": name,
        "op": op,
        "output_type": op_output_type,
        "num_inputs": len(inputs),
        "has_hash": has_hash,
        "hash_mask": hash_mask,
        "hash_prefix": hash_prefix,
        "slot": slot,
        "has_padding": has_padding,
        "pad_len": pad_len,
        "pad_val": pad_val,
    }

    if verbose:
        _print_summary(summary)

    return summary


def _validate_input_item(ctx: str, index: int, item: Any, ec: ErrorCollector) -> Optional[Dict]:
    """校验一个 input 列表项"""
    if not isinstance(item, TaggedValue):
        ec.error(f"{ctx} input[{index}] 缺少 YAML 标签（!var_* 或 !const_*）")
        return None

    tag = item.tag
    value = item.value

    if tag in VALID_VAR_TAGS:
        return _validate_var_input(ctx, index, tag, value, ec)
    elif tag in VALID_CONST_TAGS:
        return _validate_const_input(ctx, index, tag, value, ec)
    else:
        ec.error(f"{ctx} input[{index}] 未知标签 {tag!r}，有效标签：!var_* 或 !const_*")
        return None


def _validate_var_input(ctx, index, tag, value, ec) -> Optional[Dict]:
    if not isinstance(value, str) or not value:
        ec.error(f"{ctx} input[{index}] {tag} 值必须为非空字符串")
        return None

    has_prefix = any(value.startswith(p) for p in VALID_FIELD_PREFIXES)
    if not has_prefix:
        ec.error(
            f"{ctx} input[{index}] {tag} 值 {value!r} "
            f"缺少有效前缀（user. / item. / ctx.）"
        )
        return None

    for prefix in VALID_FIELD_PREFIXES:
        if value.startswith(prefix):
            field_name = value[len(prefix):]
            if not field_name:
                ec.error(
                    f"{ctx} input[{index}] {tag} 前缀 {prefix!r} 后的字段名不可为空"
                )
                return None
            return {"kind": "var", "tag": tag, "field": value, "index": index}

    return None  # unreachable


def _validate_const_input(ctx, index, tag, value, ec) -> Optional[Dict]:
    if tag in ARRAY_CONST_TAGS:
        if not isinstance(value, list):
            ec.error(
                f"{ctx} input[{index}] {tag} 对应的值必须是 YAML 序列（如 [1, 2, 3]），"
                f"当前为 {type(value).__name__!r}"
            )
            return None
    return {"kind": "const", "tag": tag, "value": value, "index": index}


def _validate_export(
    ctx: str, export_node: Dict, ec: ErrorCollector
) -> Tuple[Optional[int], bool, Optional[int], Optional[Any]]:
    """
    校验 export 块。
    返回 (slot, has_padding, pad_len, pad_val)
    """
    slot = None
    has_padding = False
    pad_len = None
    pad_val = None

    # slot
    if "slot" not in export_node:
        ec.error(f"{ctx} export 缺少必填字段 'slot'")
    else:
        slot = export_node["slot"]
        if not isinstance(slot, int) or slot < 0:
            ec.error(f"{ctx} export.slot 必须为非负整数，当前值：{slot!r}")

    # len + padding 必须成对
    has_len = "len" in export_node
    has_pad = "padding" in export_node

    if has_len != has_pad:
        missing = "padding" if has_len else "len"
        ec.error(f"{ctx} export.len 与 export.padding 必须同时出现或同时省略，缺少 '{missing}'")
    elif has_len and has_pad:
        has_padding = True
        pad_len = export_node["len"]
        pad_val = export_node["padding"]

        if not isinstance(pad_len, int) or pad_len <= 0:
            ec.error(f"{ctx} export.len 必须为正整数，当前值：{pad_len!r}")

        if not isinstance(pad_val, (int, float)):
            ec.error(
                f"{ctx} export.padding 必须为数字（整数或浮点），"
                f"当前类型：{type(pad_val).__name__!r}，值：{pad_val!r}"
            )

    return slot, has_padding, pad_len, pad_val


def _validate_type_constraints(
    ctx: str,
    op: str,
    op_output_type: str,
    has_hash: bool,
    hash_prefix: str,
    has_padding: bool,
    ec: ErrorCollector,
):
    """根据输出类型校验 hash / padding 约束"""

    if op_output_type == "int32":
        if not has_hash:
            ec.error(
                f"{ctx} op={op!r} 输出 int32 类型，必须配置 'hash' 字段"
            )

    elif op_output_type == "float" or op_output_type == "float_array":
        if not has_padding:
            ec.error(
                f"{ctx} op={op!r} 输出 float 类型，必须同时配置 'export.len' 和 'export.padding'"
            )
        if has_hash:
            ec.error(
                f"{ctx} op={op!r} 输出 float 类型，不支持 'hash' 配置"
            )

    elif op_output_type == "int64":
        if has_hash and not hash_prefix:
            ec.error(
                f"{ctx} op={op!r} 输出 int64 且启用了 hash，"
                f"'hash.prefix' 不可为空（int64 hash 要求非空 prefix）"
            )


def _print_summary(s: Dict):
    """打印单条表达式的解析摘要"""
    print(f"  ✓ {s['name']}")
    print(f"      op={s['op']} → output_type={s['output_type']}")
    print(f"      inputs={s['num_inputs']}  slot={s['slot']}")
    if s["has_hash"]:
        print(f"      hash: mask={s['hash_mask']:#x}  prefix={s['hash_prefix']!r}")
    if s["has_padding"]:
        print(f"      padding: len={s['pad_len']}  value={s['pad_val']!r}")


# ============================================================================
# 文件级校验
# ============================================================================

def validate_text(text: str, source: str, verbose: bool) -> bool:
    """
    校验一段 YAML 文本。
    source 仅用于错误提示。
    返回 True 表示全部通过。
    """
    try:
        data = load_yaml(text)
    except yaml.YAMLError as e:
        print(f"[FAIL] {source}: YAML 解析失败\n  {e}")
        return False

    if data is None:
        print(f"[WARN] {source}: 文件为空")
        return True

    # 支持两种顶层格式：
    #   1. 单条表达式（直接是 mapping）
    #   2. 多条表达式（顶层是 list of mapping）
    if isinstance(data, dict):
        expressions = [data]
    elif isinstance(data, list):
        expressions = data
    else:
        print(f"[FAIL] {source}: 顶层结构必须是 mapping 或 mapping 列表，当前：{type(data).__name__}")
        return False

    all_ok = True
    names_seen = set()

    for idx, expr in enumerate(expressions):
        if not isinstance(expr, dict):
            print(f"[FAIL] {source}: 第 {idx} 条表达式不是 mapping 类型")
            all_ok = False
            continue

        ec = ErrorCollector()
        if verbose:
            print(f"\n  --- 表达式 #{idx} ---")

        validate_expression(expr, ec, verbose=verbose)

        # 检查 name 重复
        name = expr.get("name", f"<unknown#{idx}>")
        if name in names_seen:
            ec.error(f"表达式名称 {name!r} 重复")
        names_seen.add(name)

        for w in ec.warnings:
            print(f"  [WARN]  {source}#{idx} {w}")
        for e in ec.errors:
            print(f"  [ERROR] {source}#{idx} {e}")
            all_ok = False

    return all_ok


def validate_file(path: str, verbose: bool) -> bool:
    if path == "-":
        text = sys.stdin.read()
        source = "<stdin>"
    else:
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
        except OSError as e:
            print(f"[FAIL] {path}: 无法读取文件 — {e}")
            return False
        source = path

    ok = validate_text(text, source, verbose)
    status = "PASS" if ok else "FAIL"
    print(f"[{status}] {source}")
    return ok


# ============================================================================
# CLI 入口
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="校验 fealib-cpp Expression YAML 配置文件",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "files",
        nargs="+",
        metavar="FILE",
        help="YAML 文件路径，使用 - 从 stdin 读取",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="打印每条表达式的解析摘要",
    )
    args = parser.parse_args()

    results = []
    for path in args.files:
        ok = validate_file(path, verbose=args.verbose)
        results.append(ok)

    total = len(results)
    passed = sum(results)
    failed = total - passed

    print(f"\n共 {total} 个文件，{passed} 通过，{failed} 失败")

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
