import pyfealib

fealib = pyfealib.Fealib("config.yaml")
fealib.load("./")
user = {
    "age": {"type": pyfealib.kInt32Value, "value": 25},
    "gender": {"type": pyfealib.kStringValue, "value": "male"},
    "click_item_ids": {
        "type": pyfealib.kStringArray,
        "value": ["item1", "item2", "item3"],
    },
}
ctx = {
    "country": {"type": pyfealib.kStringValue, "value": "cn"},
    "scene": {"type": pyfealib.kStringValue, "value": "home"},
}
# items = ["item-999901" for _ in range(10000)]
items = ["item-999999", "item-999998", "item-999997", "item-999996", "item-999995"]
result = fealib.run(user, ctx, items)
print(result)
