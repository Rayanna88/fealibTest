"""
Python integration tests for pyfealib.
Mirrors test/test_fealib_integration.cc — requires real test data.

Paths:
  YAML_PATH      = /home/super/shaoqing.gong/fealib-cpp/test_data/itemfeatures/fealib.yaml
  COLLECTION_DIR = /home/super/shaoqing.gong/fealib-cpp/test_data/itemfeatures/20260323194530

Skip: all tests auto-skip if COLLECTION_DIR is not found.

Column layout (from fealib.yaml, sorted by slot):
  Sparse (int64):
    [0]  user_id                       (slot  0)
    [1]  user_country                  (slot  1)
    [2]  item_packagename              (slot 10)
    [3]  item_category                 (slot 11)
    [4]  item_categoryname             (slot 12)
    [5]  item_lan                      (slot 13)
    [6]  item_status                   (slot 14)
    [7]  item_tokens_hash              (slot 20)
    [8]  item_downloadcount            (slot 40)
    [9]  item_expose_uv_7d             (slot 41)
    [10] item_click_uv_7d              (slot 42)
    [11] item_country_expose_uv_7d     (slot 50, format feature)
    [12] cross_user_country_item_category (slot 60)
    [13] cross_user_country_item_lan      (slot 61)
  Dense (float offset):
    [0]  user_install_count            (slot  2)
    [1]  item_star                     (slot 30)
    [2]  item_score                    (slot 31)

Sparse access pattern:
  zero-batch (items=[]):  sparse[col]     → list[int64]
  batch N    (items=[…]): sparse[col][b]  → list[int64]  (b = batch index)
"""

import os
import struct

import mmh3
import numpy as np
import pytest

import pyfealib

# ---------------------------------------------------------------------------
# DataType mapping  (mirrors FlatValue enum; export_values() also exposes
# them as pyfealib.kXxx, but DataType.kXxx is more readable)
# ---------------------------------------------------------------------------
DT = pyfealib.DataType

# ---------------------------------------------------------------------------
# Paths & ground-truth constants
# ---------------------------------------------------------------------------
YAML_PATH = (
    "/home/super/shaoqing.gong/fealib-cpp/test_data/itemfeatures/fealib.yaml"
)
COLLECTION_DIR = (
    "/home/super/shaoqing.gong/fealib-cpp/test_data/itemfeatures/20260323194530"
)

ITEM1 = "s_0001068bce52203a4ce39a57297a2258"
ITEM2 = "s_0003426311904e7a89be2cd4ec980dd0"

ITEM1_STAR         = 3.5
ITEM1_SCORE        = 0.0
ITEM1_DOWNLOAD     = 28493
ITEM1_EXPOSE7D     = 49
ITEM1_CLICK7D      = 0
ITEM1_TOKEN_COUNT  = 3   # "Bubble", "Fall", "3D"

ITEM2_STAR         = 4.9
ITEM2_SCORE        = 4.7
ITEM2_DOWNLOAD     = 1005304
ITEM2_EXPOSE7D     = 48
ITEM2_CLICK7D      = 3

# ---------------------------------------------------------------------------
# Column index constants
# ---------------------------------------------------------------------------
COL_USER_ID              = 0
COL_USER_COUNTRY         = 1
COL_PACKAGENAME          = 2
COL_CATEGORY             = 3
COL_CATEGORYNAME         = 4
COL_LAN                  = 5
COL_STATUS               = 6
COL_TOKENS               = 7
COL_DOWNLOAD             = 8
COL_EXPOSE7D             = 9
COL_CLICK7D              = 10
COL_EXPOSE7D_BY_COUNTRY  = 11
COL_CROSS_COUNTRY_CAT    = 12
COL_CROSS_COUNTRY_LAN    = 13

DENSE_INSTALL_CNT = 0
DENSE_STAR        = 1
DENSE_SCORE       = 2

DEFAULT_MASK = 0x1FFFFFFFFFFFFF  # 2^53 - 1

# ---------------------------------------------------------------------------
# Hash helpers — MurmurHash3_x64_128(seed=0), take hash[0] & mask
# Matches features::hash_string() in util.hpp (non-xxhash build).
#
# mmh3.hash128(key, seed, x64arch=True) returns a 128-bit unsigned int.
# Low 64 bits == hash[0] from MurmurHash3_x64_128 output array.
# ---------------------------------------------------------------------------
def _mmh3_low64(key_bytes: bytes, mask: int) -> int:
    h = mmh3.hash128(key_bytes, seed=0, x64arch=True)
    return (h & 0xFFFFFFFFFFFFFFFF) & mask


def str_hash(prefix: str, value: str, mask: int) -> int:
    """hash(prefix + value, mask)  — string features."""
    return _mmh3_low64((prefix + value).encode(), mask)


def int64_hash(prefix: str, value: int, mask: int) -> int:
    """hash(prefix + raw_bytes(int64(value)), mask)  — int64 features."""
    return _mmh3_low64(prefix.encode() + struct.pack("<q", value), mask)


def int32_hash(prefix: str, value: int, mask: int) -> int:
    """hash(prefix + raw_bytes(int32(value)), mask)  — int32 features."""
    return _mmh3_low64(prefix.encode() + struct.pack("<i", value), mask)


# ---------------------------------------------------------------------------
# Feature builders
# ---------------------------------------------------------------------------
def build_user_feats() -> dict:
    return {
        "uid":         {"type": DT.kInt64Value,  "value": 123456},
        "country":     {"type": DT.kStringValue, "value": "us"},
        "install_cnt": {"type": DT.kFloatValue,  "value": 5.0},
    }


def build_ctx_feats() -> dict:
    return {
        "country": {"type": DT.kStringValue, "value": "us"},
    }


# ---------------------------------------------------------------------------
# Helpers — sparse access for both zero-batch and normal-batch
# ---------------------------------------------------------------------------
def sparse_values(sparse, col: int, batch_idx: int, is_zero_batch: bool):
    """Return the list[int64] for (col, batch_idx).

    Zero-batch:  sparse[col]          is already the value list.
    Normal:      sparse[col][batch_idx] is the value list.
    """
    if is_zero_batch:
        return sparse[col]
    return sparse[col][batch_idx]


# ---------------------------------------------------------------------------
# Skip condition
# ---------------------------------------------------------------------------
pytestmark = pytest.mark.skipif(
    not os.path.isdir(COLLECTION_DIR),
    reason=f"Collection directory not found: {COLLECTION_DIR}",
)


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def fe():
    if not os.path.isdir(COLLECTION_DIR):
        pytest.skip(f"Collection directory not found: {COLLECTION_DIR}")
    handler = pyfealib.Fealib(YAML_PATH)
    handler.load(COLLECTION_DIR)
    return handler


# ===========================================================================
# 1. Metadata
# ===========================================================================

def test_dense_width_is3(fe):
    result = fe.run(build_user_feats(), {}, [])
    assert result["dense"].shape[1] == 3


def test_sparse_count_is14(fe):
    result = fe.run(build_user_feats(), {}, [])
    assert len(result["sparse"]) == 14


# ===========================================================================
# 2. User-only (zero-batch, items=[])
# ===========================================================================

def test_user_only_returns_user_entries(fe):
    result = fe.run(build_user_feats(), {}, [])
    sparse = result["sparse"]
    # user_id, user_country → non-empty; item cols → empty
    assert len(sparse[COL_USER_ID]) > 0
    assert len(sparse[COL_USER_COUNTRY]) > 0
    # no items → item cols should be empty lists
    for col in range(COL_PACKAGENAME, 14):
        assert len(sparse[col]) == 0, f"col {col} should be empty in zero-batch"


def test_user_only_dense_shape(fe):
    result = fe.run(build_user_feats(), {}, [])
    assert result["dense"].shape == (1, 3)


def test_user_only_install_count(fe):
    result = fe.run(build_user_feats(), {}, [])
    assert abs(result["dense"][0, DENSE_INSTALL_CNT] - 5.0) < 1e-6


def test_user_id_hash(fe):
    result = fe.run(build_user_feats(), {}, [])
    got = result["sparse"][COL_USER_ID][0]
    expected = int64_hash("uid_", 123456, 0xFFFFF)
    assert got == expected


def test_user_country_hash(fe):
    result = fe.run(build_user_feats(), {}, [])
    got = result["sparse"][COL_USER_COUNTRY][0]
    expected = str_hash("co_", "us", 0xFFFF)
    assert got == expected


# ===========================================================================
# 3. Item features — item1
# ===========================================================================

def test_item1_star(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    print(f"{result}")
    assert abs(result["dense"][0, DENSE_STAR] - ITEM1_STAR) < 1e-4


def test_item1_score(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    assert abs(result["dense"][0, DENSE_SCORE] - ITEM1_SCORE) < 1e-4


def test_item1_download(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_DOWNLOAD][0][0]
    expected = int32_hash("i_dlc_", ITEM1_DOWNLOAD, DEFAULT_MASK)
    assert got == expected


def test_item1_expose7d(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_EXPOSE7D][0][0]
    expected = int32_hash("i_euv7d_", ITEM1_EXPOSE7D, DEFAULT_MASK)
    assert got == expected


def test_item1_click7d(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_CLICK7D][0][0]
    expected = int32_hash("i_cuv7d_", ITEM1_CLICK7D, DEFAULT_MASK)
    assert got == expected


def test_item1_category(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_CATEGORY][0][0]
    expected = str_hash("cat_", "Game", 0xFFFF)
    assert got == expected


def test_item1_lan(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_LAN][0][0]
    expected = str_hash("lan_", "en", 0xFFFF)
    assert got == expected


def test_item1_tokens_padded_to8(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    tokens = result["sparse"][COL_TOKENS][0]
    assert len(tokens) == 8
    # padding slots are zero
    for i in range(ITEM1_TOKEN_COUNT, 8):
        assert tokens[i] == 0, f"padding slot [{i}] should be 0"
    # actual token slots are non-zero
    non_zero = sum(1 for t in tokens[:ITEM1_TOKEN_COUNT] if t != 0)
    assert non_zero == ITEM1_TOKEN_COUNT
    # first token = hash("tok_" + "Bubble")
    assert tokens[0] == str_hash("tok_", "Bubble", 0xFFFFF)


def test_item1_packagename(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_PACKAGENAME][0][0]
    expected = str_hash("pkg_", "com.tarboosh.bubblefall3d", 0xFFFFF)
    assert got == expected


# ===========================================================================
# 4. Item features — item2
# ===========================================================================

def test_item2_star(fe):
    result = fe.run(build_user_feats(), {}, [ITEM2])
    assert abs(result["dense"][0, DENSE_STAR] - ITEM2_STAR) < 0.01


def test_item2_score(fe):
    result = fe.run(build_user_feats(), {}, [ITEM2])
    assert abs(result["dense"][0, DENSE_SCORE] - ITEM2_SCORE) < 1e-4


def test_item2_download(fe):
    result = fe.run(build_user_feats(), {}, [ITEM2])
    got = result["sparse"][COL_DOWNLOAD][0][0]
    expected = int32_hash("i_dlc_", ITEM2_DOWNLOAD, DEFAULT_MASK)
    assert got == expected


def test_item2_click7d(fe):
    result = fe.run(build_user_feats(), {}, [ITEM2])
    got = result["sparse"][COL_CLICK7D][0][0]
    expected = int32_hash("i_cuv7d_", ITEM2_CLICK7D, DEFAULT_MASK)
    assert got == expected


def test_item2_categoryname(fe):
    result = fe.run(build_user_feats(), {}, [ITEM2])
    got = result["sparse"][COL_CATEGORYNAME][0][0]
    expected = str_hash("catn_", "Role Playing", 0xFFFF)
    assert got == expected


# ===========================================================================
# 5. Batch of 2 items
# ===========================================================================

def test_batch2_dense_shape(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1, ITEM2])
    assert result["dense"].shape == (2, 3)


def test_batch2_item_stars(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1, ITEM2])
    dense = result["dense"]
    assert abs(dense[0, DENSE_STAR] - ITEM1_STAR) < 1e-4
    assert abs(dense[1, DENSE_STAR] - ITEM2_STAR) < 0.01


def test_user_features_broadcast_to_all_items(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1, ITEM2])
    sparse = result["sparse"]
    # user_id and user_country broadcast: same value for both items
    assert sparse[COL_USER_ID][0] == sparse[COL_USER_ID][1]
    assert sparse[COL_USER_COUNTRY][0] == sparse[COL_USER_COUNTRY][1]


# ===========================================================================
# 6. Entry count cross-check
# ===========================================================================

def test_item1_total_entries_no_ctx(fe):
    # 3 user + 13 item (11 original + 2 cross, format absent) = 16
    result = fe.run(build_user_feats(), {}, [ITEM1])
    sparse = result["sparse"]
    dense = result["dense"]
    # All item sparse cols except format (col 11) should be non-empty
    for col in [COL_PACKAGENAME, COL_CATEGORY, COL_CATEGORYNAME, COL_LAN,
                COL_STATUS, COL_TOKENS, COL_DOWNLOAD, COL_EXPOSE7D,
                COL_CLICK7D, COL_CROSS_COUNTRY_CAT, COL_CROSS_COUNTRY_LAN]:
        assert len(sparse[col][0]) > 0, f"col {col} should be non-empty"
    # Format feature absent without ctx
    assert len(sparse[COL_EXPOSE7D_BY_COUNTRY][0]) == 0


# ===========================================================================
# 7. Format feature (composite-key: context.country + column name)
# ===========================================================================

def test_format_feature_no_ctx_absent(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    assert len(result["sparse"][COL_EXPOSE7D_BY_COUNTRY][0]) == 0, \
        "format feature must be absent without ctx"


def test_format_feature_with_ctx_does_not_crash(fe):
    result = fe.run(build_user_feats(), build_ctx_feats(), [ITEM1])
    assert result is not None
    assert "sparse" in result


def test_format_feature_with_ctx_item_entry_count(fe):
    # Format feature (col 11) uses composite key "country:column_name".
    # Even with ctx, if the collection has no data for that composite key,
    # the lookup silently returns nothing → col 11 stays empty.
    # This test collection lacks the key → 11 non-empty item cols (not 12).
    result = fe.run(build_user_feats(), build_ctx_feats(), [ITEM1])
    sparse = result["sparse"]
    nonempty = sum(1 for col in range(COL_PACKAGENAME, 14)
                   if len(sparse[col][0]) > 0)
    # col 11 absent in this collection → 11; if data present → 12
    print(f"{sparse}")
    assert nonempty == 12


# ===========================================================================
# 8. Cross features
# ===========================================================================

def test_cross_country_cat_item1(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_CROSS_COUNTRY_CAT][0][0]
    # concat_ws("@", user.country="us", item.categoryname="Puzzle") = "us@Puzzle"
    expected = str_hash("co_cat_", "us@Puzzle", 0x1FFFF)
    assert got == expected


def test_cross_country_lan_item1(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    got = result["sparse"][COL_CROSS_COUNTRY_LAN][0][0]
    # concat_ws("@", user.country="us", item.lan="en") = "us@en"
    expected = str_hash("co_lan_", "us@en", 0xFFFF)
    assert got == expected


def test_cross_country_cat_item2(fe):
    result = fe.run(build_user_feats(), {}, [ITEM2])
    got = result["sparse"][COL_CROSS_COUNTRY_CAT][0][0]
    # item2 categoryname = "Role Playing"
    expected = str_hash("co_cat_", "us@Role Playing", 0x1FFFF)
    assert got == expected
    # differs from item1
    assert got != str_hash("co_cat_", "us@Puzzle", 0x1FFFF)


def test_cross_features_on_item_row_not_user(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1])
    sparse = result["sparse"]
    # Cross feature values exist on item row (batch index 0), not just user row
    assert len(sparse[COL_CROSS_COUNTRY_CAT][0]) > 0
    assert len(sparse[COL_CROSS_COUNTRY_LAN][0]) > 0


def test_cross_country_cat_differs_between_items(fe):
    result = fe.run(build_user_feats(), {}, [ITEM1, ITEM2])
    sparse = result["sparse"]
    cat1 = sparse[COL_CROSS_COUNTRY_CAT][0][0]
    cat2 = sparse[COL_CROSS_COUNTRY_CAT][1][0]
    assert cat1 != cat2, "different items should produce different cross feature values"


# ===========================================================================
# 9. Memory / idempotence
# ===========================================================================

def test_repeated_calls_are_deterministic(fe):
    r1 = fe.run(build_user_feats(), {}, [ITEM1])
    r2 = fe.run(build_user_feats(), {}, [ITEM1])
    assert r1["sparse"][COL_DOWNLOAD][0][0] == r2["sparse"][COL_DOWNLOAD][0][0]
    np.testing.assert_array_equal(r1["dense"], r2["dense"])


def test_delete_response_does_not_crash(fe):
    # Python GC handles memory; just ensure multiple calls don't raise
    for _ in range(10):
        result = fe.run(build_user_feats(), {}, [ITEM1, ITEM2])
        assert result is not None
