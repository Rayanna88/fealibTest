import pyfealib

fealib = pyfealib.Fealib("output.yaml")

user = {
    "k0": {"type": pyfealib.kInt32Value, "value": 25},
    "k1": {"type": pyfealib.kInt32Array, "value": [1, 2, 3, 4, 5, 6, 7]},
    "k2": {"type": pyfealib.kFloatValue, "value": 0.3},
    "k3": {"type": pyfealib.kFloatArray, "value": [0.1, 0.2, 0.3, 0.4]},
    "k4": {"type": pyfealib.kInt64Value, "value": 222222222},
    "k5": {"type": pyfealib.kInt64Array, "value": [11111111, 2222222, 333333, 4444444]},
    "k6": {"type": pyfealib.kStringValue, "value": "hello world"},
    "k7": {
        "type": pyfealib.kStringArray,
        "value": [
            "hello world",
            "#####hello ###world",
            "\n\r#####hello ###world  ",
        ],
    },
    "gender": {"type": pyfealib.kStringValue, "value": "male"},
    "click_item_ids": {
        "type": pyfealib.kStringArray,
        "value": ["item1", "item2", "item3"],
    },
}
ctx = {
    "country": {"type": pyfealib.kStringValue, "value": "cn"},
    "scene": {"type": pyfealib.kStringValue, "value": "home"},
}
# items = ["item-999901" for _ in range(10000)]
items = ["item-999999", "item-999998", "item-999997", "item-999996", "item-999995"]
result = fealib.run(user, ctx, [])
print(result)
